

class Test(object):

    def __init__(self):
        pass

    def test(self):
        pass

if __name__ == '__main__':
    import nose
    nose.run(argv=[__file__, '-s', '-v'])
